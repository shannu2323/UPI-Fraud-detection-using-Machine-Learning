import React from "react";

const Result = () => {
  return <div>Result</div>;
};

export default Result;
